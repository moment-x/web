import tencentyun
import time

SECRET_ID = 'AKIDpfLlXhjLoRSEACPSgmqKbTjrnIiyscvR'
SECRET_KEY = 'IMbbMjxmuo7a9Bs2lYijE6Ys79i8y6qC'
URL = 'http://atest-10002458.image.myqcloud.com/atest-10002458'
BUCKET = 'atest'
AUTH = tencentyun.Auth(SECRET_ID, SECRET_KEY)


def multipleEntrySign():
     expired = int(time.time()) + 999
     sign = AUTH.get_app_sign_v2(BUCKET, 'atestadsfasf', expired)
     print(sign)

